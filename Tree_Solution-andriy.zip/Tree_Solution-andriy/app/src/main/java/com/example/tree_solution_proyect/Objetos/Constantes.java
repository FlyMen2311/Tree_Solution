package com.example.tree_solution_proyect.Objetos;

import com.google.firebase.auth.FirebaseAuth;

public class Constantes {
    public static final String URL_FOTO_PERFIL="https://firebasestorage.googleapis.com" +
            "/v0/b/treesolution-38dca.appspot.com/o/foto_perfil%2F1455555011_users-10_" +
            "icon-icons.com_53271.png?alt=media&token=9dde87d9-f4a5-4451-bc5b-c9be88c8763e";
    public static final String NODO_USUARIOS="Usuarios";
    public static final String NODO_LIBROS="Libros";
    public static final String NODO_CHAT_DATOS="Datos_chat";
    public static final String NODO_CHATS="Chats";
    public static final String NODO_LIB_FAV="Libros_favoritos";


}
