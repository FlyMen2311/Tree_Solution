package com.example.tree_solution_proyect.Vistas;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tree_solution_proyect.R;

/*solamente para mostrar el layout*/
public class PoliticaPrivacidadActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_politicaprivacidad);
    }
}
