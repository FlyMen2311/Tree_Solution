package com.example.tree_solution_proyect.Objetos;

public class Constantes {

    public static final String URL_FOTO_PERFIL="gs://treesolution-38dca.appspot.com/foto_perfil/1455555011_users-10_icon-icons.com_53271.png";
    public static final String NODO_USUARIOS="Usuarios";
}
